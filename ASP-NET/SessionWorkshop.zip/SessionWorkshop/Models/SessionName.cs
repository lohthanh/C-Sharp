namespace SessionWorkshop.Models;
using System.ComponentModel.DataAnnotations;

public class SessionName
{   
    [Required]
    public string Name { get; set; }

}
