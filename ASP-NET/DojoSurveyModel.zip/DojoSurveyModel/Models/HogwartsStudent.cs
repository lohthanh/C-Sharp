public class HogwartsStudent {
    public string? Name {get; set;}
    public string? House {get; set;}
    public int? CurrentYear {get; set;}
}